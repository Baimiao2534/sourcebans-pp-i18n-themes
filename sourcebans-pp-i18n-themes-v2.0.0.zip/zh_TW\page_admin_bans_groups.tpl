{*
    SourceBans++ 2026 — page_admin_bans_groups.tpl
    Bound to Sbpp\View\AdminBansGroupsView (validated by SmartyTemplateRule).

    "Group ban" tab on the admin bans page. Two modes share this surface:
      - Default: a small form to ban a Steam community group by URL.
        Submission goes through the page-tail JS in admin.bans.php
        (event-delegated `data-action="groupban-*"` dispatcher → chains
        `Actions.BansGroupBan` + `Actions.BansBanMemberOfGroup`).
      - "From player" mode (?fid=STEAMID): the inline LoadGetGroups
        helper below enumerates the player's group memberships into
        the #steamGroupsTable list; ticking groups + clicking
        "Add Group Ban" runs the bulk dispatch (one BansGroupBan +
        BansBanMemberOfGroup pair per selected group).

    #1402 — Migrated `onclick="ProcessGroupBan();"` /
    `onclick="CheckGroupBan();"` / `onclick="TickSelectAll();"`
    bindings to `data-action="…"` attributes per AGENTS.md
    "Add a confirm + reason modal …" (the canonical-shape rule for
    rewiring dead sourcebans.js helpers). The three globals lived
    in web/scripts/sourcebans.js (deleted at #1123 D1); every click
    was a `ReferenceError: ProcessGroupBan is not defined` (loud
    sister-shape of the #1397 / #1352 trash-can bug). The new
    dispatcher in admin.bans.php's tail script binds against the
    data-attributes and uses sb.api.call → window.SBPP.setBusy /
    showToast for the loading state + final feedback.

    DOM ids (groupurl, groupreason, *.msg, agban, aback, gban,
    tickswitch, tickswitchlink, steamGroups, steamGroupsText,
    steamGroupsTable, steamGroupStatus) are preserved so existing
    LoadGetGroups inline script + any third-party theme that wired
    extra behaviour on top still finds them.

    `$player_name` is rendered above the group list when reaching this
    tab from a banlist row (?fid=STEAMID&player=…). admin.bans.php
    currently passes an empty string; Phase B/C may wire the lookup
    later, the placeholder is here so SmartyTemplateRule sees the
    template + view are in agreement.
*}
{if NOT $permission_addban}
    <div class="card" data-testid="groupban-denied">
        <div class="card__body">
            <h1 style="font-size:1.25rem;font-weight:600;margin:0">存取被拒絕</h1>
            <p class="text-sm text-muted m-0 mt-2">您沒有新增封禁的權限。</p>
        </div>
    </div>
{else}
    {if NOT $groupbanning_enabled}
        <div class="card" data-testid="groupban-disabled">
            <div class="card__body">
                <h1 style="font-size:1.25rem;font-weight:600;margin:0">功能已停用</h1>
                <p class="text-sm text-muted m-0 mt-2">
                    分組封禁功能已於
                    <strong>config.enablegroupbanning</strong> 中關閉。
                    請從設定分頁重新啟用以使用此功能。
                </p>
            </div>
        </div>
    {else}
        <section class="p-6" data-testid="groupban-section" style="max-width:48rem">
            <div class="mb-6">
                <h1 style="font-size:1.5rem;font-weight:600;margin:0">分組封禁</h1>
                <p class="text-sm text-muted m-0 mt-2">
                    一次封禁 Steam 社群分組的所有成員。
                </p>
            </div>

            {if NOT $list_steam_groups}
                <form id="groupban-form"
                      class="card p-6 space-y-4"
                      data-testid="groupban-form"
                      onsubmit="event.preventDefault(); return false;">
                    {csrf_field}
                    <div>
                        <label class="label" for="groupurl">Steam 社群分組網址</label>
                        <input type="text"
                               class="input font-mono"
                               id="groupurl"
                               name="groupurl"
                               data-testid="groupban-url"
                               placeholder="http://steamcommunity.com/groups/interwavestudios">
                        <div class="text-xs mt-2" id="groupurl.msg" style="color:var(--danger);display:none"></div>
                    </div>
                    <div>
                        <label class="label" for="groupreason">分組封禁原因</label>
                        <textarea class="textarea"
                                  id="groupreason"
                                  name="groupreason"
                                  rows="4"
                                  placeholder="為何要封禁此分組？"
                                  data-testid="groupban-reason"></textarea>
                        <div class="text-xs mt-2" id="groupreason.msg" style="color:var(--danger);display:none"></div>
                    </div>
                    <div class="flex justify-end gap-2"
                         style="border-top:1px solid var(--border);padding-top:0.75rem">
                        <button type="button"
                                class="btn btn--ghost"
                                id="aback"
                                data-testid="groupban-back"
                                onclick="history.go(-1);">返回</button>
                        {* #1402: was `onclick="ProcessGroupBan();"` which threw
                           ReferenceError post-#1123 D1 (the helper lived in the
                           deleted sourcebans.js). The page-tail dispatcher in
                           admin.bans.php picks up data-action="groupban-submit"
                           and chains Actions.BansGroupBan → BansBanMemberOfGroup. *}
                        <button type="button"
                                class="btn btn--primary"
                                id="agban"
                                data-testid="groupban-submit"
                                data-action="groupban-submit">
                            新增分組封禁
                        </button>
                    </div>
                </form>
            {else}
                <div class="card p-6 space-y-4" data-testid="groupban-from-player">
                    <p class="text-sm text-muted m-0">
                        {if $player_name}
                            <strong class="font-medium">{$player_name|escape}</strong> 所屬的分組已載入下方。
                        {else}
                            玩家所屬的所有分組列於此處。
                        {/if}
                        勾選您要封禁的分組。
                    </p>

                    <div id="steamGroupsText"
                         name="steamGroupsText"
                         class="text-sm text-muted">正在載入分組…</div>

                    <div id="steamGroups"
                         name="steamGroups"
                         style="display:none">
                        <table id="steamGroupsTable"
                               name="steamGroupsTable"
                               class="table"
                               style="margin-bottom:1rem">
                            <thead>
                                <tr>
                                    <th style="width:2.5rem">
                                        {* #1402: was `onclick="TickSelectAll();"` (dead since #1123 D1). *}
                                        <button type="button"
                                                id="tickswitch"
                                                name="tickswitch"
                                                class="btn btn--secondary btn--sm btn--icon"
                                                data-action="groupban-select-all"
                                                title="全選">+</button>
                                    </th>
                                    <th>分組</th>
                                </tr>
                            </thead>
                        </table>
                        {* #1402: was `onclick="TickSelectAll();return false;"`. *}
                        <a class="btn btn--ghost btn--sm"
                           href="#"
                           data-action="groupban-select-all"
                           name="tickswitchlink"
                           id="tickswitchlink">全選</a>

                        <div class="mt-4">
                            <label class="label" for="groupreason">分組封禁原因</label>
                            <textarea class="textarea"
                                      id="groupreason"
                                      name="groupreason"
                                      rows="4"
                                      placeholder="為何要封禁此分組？"
                                      data-testid="groupban-reason"></textarea>
                            <div class="text-xs mt-2" id="groupreason.msg" style="color:var(--danger);display:none"></div>
                        </div>

                        <div class="flex justify-end gap-2 mt-4">
                            {* #1402: was `onclick="CheckGroupBan();"` which threw
                               ReferenceError. The page-tail dispatcher in
                               admin.bans.php picks up data-action="groupban-bulk-submit"
                               and iterates ticked rows through the same chain. *}
                            <button type="button"
                                    class="btn btn--primary"
                                    id="gban"
                                    name="gban"
                                    data-testid="groupban-bulk-submit"
                                    data-action="groupban-bulk-submit">
                                新增分組封禁
                            </button>
                        </div>
                    </div>

                    <div id="steamGroupStatus"
                         name="steamGroupStatus"
                         class="text-sm" style="width:100%"></div>
                </div>
                {* $list_steam_groups is the literal value of $_GET['fid'] dropped into a JS string argument.
                   Smarty's default HTML escape (init.php's setEscapeHtml(true)) renders `'` as the literal
                   six-character sequence `&#039;` — inside a <script> element the browser does NOT decode
                   character references, so the JS string parser sees those six characters as part of the
                   string contents and never terminates early. Matches the legacy default theme's behaviour.
                   DO NOT add `nofilter` here without an alternative escape (e.g. json_encode in the View);
                   doing so re-opens a reflected XSS via `?p=admin&c=bans&fid=…');alert(1);//`. *}
                <script>
                {literal}
                // Inlined sourcebans.js helper (#1123 D1 prep): the legacy LoadGetGroups lives in
                // sourcebans.js, which sbpp2026 doesn't load. Vanilla replacement against
                // Actions.BansGetGroups; mirrors the legacy DOM-ops shape so #steamGroupsTable
                // rows stay structurally identical (TickSelectAll / CheckGroupBan keep working).
                (function (friendid) {
                    sb.ready(function () {
                        sb.api.call(Actions.BansGetGroups, { friendid: friendid }).then(function (r) {
                            if (!r || !r.ok || !r.data) return;
                            var groups = r.data.groups || [];
                            var tbl = sb.$id('steamGroupsTable');
                            if (!tbl) return;
                            if (groups.length === 0) {
                                sb.message.error('錯誤', "擷取分組資料時發生錯誤。可能是玩家不屬於任何分組或其個人檔案為私人？", 'index.php?p=banlist');
                                var txt = sb.$id('steamGroupsText');
                                if (txt) txt.innerHTML = '<i>無分組...</i>';
                                return;
                            }
                            groups.forEach(function (g, i) {
                                var safeUrl = encodeURIComponent(String(g.url || ''));
                                var tr = tbl.insertRow();
                                var td1 = tr.insertCell();
                                td1.style.padding = '0px';
                                td1.style.width = '3px';
                                var cb = document.createElement('input');
                                cb.type = 'checkbox';
                                cb.id = 'chkb_' + i;
                                cb.value = String(g.url || '');
                                td1.appendChild(cb);
                                var td2 = tr.insertCell();
                                var a = document.createElement('a');
                                a.href = 'http://steamcommunity.com/groups/' + safeUrl;
                                a.target = '_blank';
                                a.rel = 'noopener noreferrer';
                                a.textContent = String(g.name || '');
                                td2.appendChild(a);
                                td2.appendChild(document.createTextNode(' ('));
                                var span = document.createElement('span');
                                span.id = 'membcnt_' + i;
                                span.setAttribute('value', String(g.member_count || 0));
                                span.textContent = String(g.member_count || 0);
                                td2.appendChild(span);
                                td2.appendChild(document.createTextNode(' 位成員)'));
                            });
                            sb.hide('steamGroupsText');
                            sb.show('steamGroups');
                        });
                    });
                })({/literal}'{$list_steam_groups}'{literal});
                {/literal}
                </script>
            {/if}
        </section>
    {/if}
{/if}
