-{*
    SourceBans++ 2026 — page_login.tpl

    Replaces the A1 stub. Pair: web/pages/page.login.php +
    web/includes/View/LoginView.php (#1123 B1).

    Delimiters
    ----------
    This template renders with the `-{ … }-` delimiter pair (the page
    handler swaps them in around the Renderer::render() call, mirroring
    `web/pages/page.youraccount.php`). Two reasons:

      1. The legacy `web/themes/default/page_login.tpl` already uses
         `-{ … }-`, so the same View can drive both templates without
         a per-theme delimiter conditional in the page handler.
      2. The inline `<script>` block at the bottom is large enough that
         wrapping every JS object literal in `{literal}…{/literal}` for
         the standard `{ … }` pair would noise the template up. With
         `-{ … }-` the `{` / `}` JS punctuation is plain text.

    The other sbpp2026 templates use the standard `{ … }` pair; this
    template is the only `-{ … }-` page in the new theme, matching the
    legacy default theme's per-template oddity. #1123 D1 will rewrite
    both halves to standard `{ … }` once the legacy bundle is deleted.

    Why this differs from handoff/pages/login.tpl
    ---------------------------------------------
    handoff/pages/login.tpl renders a full-viewport 2-column split
    (sign-in card + dark marketing hero) by escaping the React app
    shell. The repo's web/includes/page-builder.php always wraps
    every page in core/{header,navbar,title,footer}.tpl, so the
    full-viewport trick collides with the chrome added in #1123 A2.
    Per the B1 dispatch ("strip the demo's 'stat panel right' if no
    data feeds it cheaply"), we drop the hero aside and render a
    single centered sign-in card inside the page slot. The chrome's
    breadcrumb / ⌘K / theme toggle stay visible — they're harmless
    on the login page and removing them would require touching
    chrome PHP that B1 must not touch.

    Error banner -> toast
    ---------------------
    The legacy theme echoes ShowBox() JS dialogs from the page handler
    on `?m=failed` / `?m=locked` / etc. The new chrome drops
    web/scripts/sourcebans.js (#1123 D1), so ShowBox() is undefined
    here. Instead, the inline <script> reads the `?m=…` (and `?time=…`)
    query parameters and surfaces them via window.SBPP.showToast(),
    which theme.js (vendored at A1) exposes globally. Keeping the
    message text client-side keeps the LoginView property surface
    aligned with the legacy template (no baseline entries needed for
    the dual-theme PHPStan matrix during the rollout window).

    Form submit
    -----------
    The form posts via sb.api.call(Actions.AuthLogin, …) (NOT a string
    literal — see AGENTS.md "Frontend"). api.js's call() honours the
    `redirect` envelope automatically (sets window.location), which is
    how the existing api_auth_login handler signals both success ("?")
    and failure ("?p=login&m=failed"); we don't have to handle the
    response body here.

    Testability hooks (per #1123 B1 dispatch + AGENTS.md)
    ------------------------------------------------------
      data-testid="login-form"      — outer <form>
      data-testid="login-username"  — username text input
      data-testid="login-password"  — password input
      data-testid="login-remember"  — remember-me checkbox
      data-testid="login-submit"    — submit button
      data-testid="login-steam"     — "Continue with Steam" link
      data-testid="login-disabled"  — banner shown when both methods are off
      data-testid="login-lostpwd"   — lost-password link
*}-
<div class="login-shell">
    <div class="card login-shell__card">
        <div class="card__body">
            <div class="flex items-center gap-3 mb-6">
                -{* #1235 — brand mark is the operator-configurable
                   `template.logo` setting, theme-resolved in the page
                   handler (page.login.php) and passed in as
                   `$brand_logo_url`. Default ships as the SourceBans++
                   shield from the favicon set.

                   #1480 — `data-testid="brand-mark"` lets the
                   `brand-mark-resolution.spec.ts` E2E spec anchor on
                   the rendered `<img>` element without relying on the
                   `sidebar__brand-mark` CSS class chain (per
                   AGENTS.md "selectors must use testability hooks").
                   The same testid is mirrored on `core/navbar.tpl`'s
                   sidebar brand mark so the spec walks both surfaces
                   with one selector. *}-
                <img class="sidebar__brand-mark" data-testid="brand-mark" src="-{$brand_logo_url}-" alt="" aria-hidden="true">
                <div>
                    <div class="font-semibold text-sm">SourceBans++</div>
                    <div class="text-xs text-muted">管理面板</div>
                </div>
            </div>

            <h1 class="m-0" style="font-size:var(--fs-2xl);font-weight:600">登录</h1>
            <p class="text-sm text-muted mt-2">使用您的管理员凭据，或通过 Steam 登录。</p>

            -{if !$normallogin_show and !$steamlogin_show}-
                <div class="toast"
                     role="status"
                     data-testid="login-disabled"
                     style="margin-top:1.5rem">
                    <i data-lucide="info" style="color:var(--info)" aria-hidden="true"></i>
                    <div class="text-sm">
                        登录当前已禁用。请联系站点管理员。
                    </div>
                </div>
            -{/if}-

            -{if $steamlogin_show}-
                <a class="btn btn--secondary"
                   href="index.php?p=login&amp;o=steam"
                   data-testid="login-steam"
                   style="width:100%;margin-top:1.5rem">
                    <i data-lucide="gamepad-2" aria-hidden="true"></i> 使用 Steam 登录
                </a>
            -{/if}-

            -{if $steamlogin_show and $normallogin_show}-
                <div class="login-shell__divider" aria-hidden="true">
                    <span>或使用凭据</span>
                </div>
            -{/if}-

            -{*
                The page handler emits `$redir` as a JS expression
                (currently "DoLogin('');") that the LEGACY default theme
                inlines into its button onclick and Enter/Space keydown
                handlers. The new form posts via sb.api.call(Actions.AuthLogin)
                directly, so `$redir` is unused for login wiring here — but
                we still echo it on a dead `data-legacy-redir` attribute so
                SmartyTemplateRule sees the reference (otherwise the sbpp2026
                leg of the dual-theme PHPStan matrix added in #1123 A2 would
                fire `unusedProperty` for LoginView::$redir). Auto-escape is
                on globally (init.php → setEscapeHtml(true)) so the JS
                punctuation lands HTML-encoded inside the attribute and is
                never executed. The attribute and the View property both go
                away when #1123 D1 deletes the legacy template.
            *}-
            -{if $normallogin_show}-
                <form id="loginForm"
                      class="space-y-3"
                      method="post"
                      action="index.php?p=login"
                      data-testid="login-form"
                      data-legacy-redir="-{$redir}-"
                      novalidate
                      autocomplete="on">
                    -{csrf_field}-

                    <div>
                        <label class="label" for="loginUsername">用户名</label>
                        <input class="input"
                               id="loginUsername"
                               name="username"
                               type="text"
                               autocomplete="username"
                               required
                               data-testid="login-username">
                    </div>

                    <div>
                        <label class="label" for="loginPassword">密码</label>
                        <input class="input"
                               id="loginPassword"
                               name="password"
                               type="password"
                               autocomplete="current-password"
                               required
                               data-testid="login-password">
                    </div>

                    <label class="flex items-center gap-2 text-xs text-muted" for="loginRememberMe">
                        <input id="loginRememberMe"
                               type="checkbox"
                               name="remember"
                               value="1"
                               checked
                               data-testid="login-remember">
                        在此设备上记住我
                    </label>

                    <button class="btn btn--primary"
                            type="submit"
                            data-testid="login-submit"
                            style="width:100%;margin-top:.5rem">
                        登录 <i data-lucide="arrow-right" aria-hidden="true"></i>
                    </button>
                </form>

                <div class="mt-4 text-xs" style="text-align:center">
                    <a href="index.php?p=lostpassword" data-testid="login-lostpwd">忘记密码？</a>
                </div>
            -{/if}-
        </div>
    </div>
</div>

<style>
    .login-shell { display:flex; justify-content:center; padding:2.5rem 1rem; }
    .login-shell__card { width:100%; max-width:24rem; }
    .login-shell__divider { position:relative; margin:1.25rem 0; }
    .login-shell__divider::before {
        content:""; position:absolute; inset:50% 0 auto 0;
        border-top:1px solid var(--border);
    }
    .login-shell__divider > span {
        position:relative; display:block; width:max-content; margin:0 auto;
        background:var(--bg-surface); padding:0 .5rem;
        font-size:.625rem; letter-spacing:.06em; text-transform:uppercase;
        color:var(--text-faint);
    }
</style>

<script>
(function () {
    'use strict';

    /**
     * Flip the busy / loading state on a triggered action button. Calls
     * window.SBPP.setBusy when present (theme.js owns the spinner CSS
     * contract) and falls back to plain `disabled` so third-party themes
     * that strip theme.js still gate against double-clicks.
     */
    function setBusy(btn, busy) {
        if (!btn) return;
        var S = window.SBPP;
        if (S && typeof S.setBusy === 'function') S.setBusy(btn, busy);
        else btn.disabled = busy === undefined ? true : !!busy;
    }

    // ----- form submit -> sb.api.call(Actions.AuthLogin, ...) ---------
    // `redirect` is the post-login destination passed to the JSON API
    // (`web/api/handlers/auth.php` → `Api::redirect('?' . <redir-param>)`).
    // Empty string lands on `?` which the dashboard/route handler
    // resolves to the home page. The `data-legacy-redir` attribute on
    // the <form> carries the legacy theme's `$redir` JS expression for
    // SmartyTemplateRule parity only — the new flow never reads it.
    var form = document.getElementById('loginForm');
    if (form) {
        form.addEventListener('submit', function (e) {
            e.preventDefault();
            var u = document.getElementById('loginUsername');
            var p = document.getElementById('loginPassword');
            var r = document.getElementById('loginRememberMe');
            // Flip the Sign in button into the busy state immediately —
            // sb.api.call honours the `redirect` envelope automatically
            // (window.location.href = …) on success, so we don't need
            // to release on the success path; on failure the server's
            // redirect envelope (back to ?p=login&m=…) navigates away
            // too. The setBusy is purely the in-flight cue between
            // click and navigation, which is otherwise invisible on a
            // slow network (#XXXX).
            var submitBtn = form.querySelector('[data-testid="login-submit"]');
            setBusy(submitBtn, true);
            sb.api.call(Actions.AuthLogin, {
                username: u ? u.value : '',
                password: p ? p.value : '',
                remember: !!(r && r.checked),
                redirect: ''
            }).then(function (res) {
                // Defensive release: if the dispatcher returned a non-
                // redirect envelope (e.g. an unexpected error shape that
                // didn't navigate), restore the button so the user can
                // retry without a hard reload. The success / standard-
                // failure paths navigate before this fires.
                if (!res || !res.redirect) setBusy(submitBtn, false);
            }, function () {
                setBusy(submitBtn, false);
            });
        });
    }

    // ----- ?m=… query-param -> SBPP.showToast(...) -------------------
    // Replaces the legacy theme's per-message ShowBox() <script>
    // emitted from web/pages/page.login.php. Driving the toast
    // client-side keeps the message text out of the LoginView's
    // property surface (and therefore out of the dual-theme PHPStan
    // baseline) during the rollout window.
    var params = new URLSearchParams(window.location.search);
    var m = params.get('m');
    if (!m) return;
    var time = parseInt(params.get('time') || '0', 10);
    var lockedBody = '由于登录失败次数过多，您的账户已被临时锁定。'
                   + '请约 ' + time + ' 分钟后再试。';
    var msgs = {
        no_access:    { kind: 'error', title: '无访问权限',          body: '您没有权限访问此页面。请使用具有访问权限的账户登录。' },
        empty_pwd:    { kind: 'info',  title: '空密码',               body: '您的账户设置了空密码。请通过忘记密码链接重置，或联系管理员处理。' },
        failed:       { kind: 'error', title: '登录失败',             body: '您提供的用户名或密码不正确。如果忘记密码，请使用下方的忘记密码链接。' },
        steam_failed: { kind: 'error', title: 'Steam 登录失败',       body: 'Steam 登录成功，但您的 SteamID 未与任何账户关联。' },
        locked:       { kind: 'error', title: '账户已锁定',           body: lockedBody }
    };
    var msg = msgs[m];
    if (!msg) return;
    function show() {
        if (window.SBPP && typeof window.SBPP.showToast === 'function') {
            window.SBPP.showToast({ kind: msg.kind, title: msg.title, body: msg.body });
        } else {
            // theme.js still loading; retry on next tick.
            setTimeout(show, 50);
        }
    }
    show();
}());
</script>
